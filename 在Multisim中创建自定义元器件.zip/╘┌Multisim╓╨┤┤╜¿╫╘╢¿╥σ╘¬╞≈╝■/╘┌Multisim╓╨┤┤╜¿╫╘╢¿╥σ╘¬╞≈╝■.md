# 利用SPICE模型在Multisim中创建自定义元器件

[TOC]

### 参考资料

[NI Multisim元件库：在Multisim中创建自定义元器件](http://www.ni.com/tutorial/3173/zhs/)

[Error The Model Contains Top-Level .subckt Statements in Multisim](https://knowledge.ni.com/KnowledgeArticleDetails?id=kA00Z0000019VTuSAM&l=zh-CN)

[.subckt definitions](https://www.multisim.com/help/components/creating-custom-component-models/subckt-definitions/)

[如何在Multisim中导入和导出组件？](https://knowledge.ni.com/KnowledgeArticleDetails?id=kA00Z000000P6VLSA0&l=zh-CN)

[模型下载站pspice](https://www.pspice.com/models/analog-devices)

### 步骤1 找到需要的元器件的SPICE模型

在网上找了好久，有一个网站还算靠谱，在上面可以下载到所需的SPICE模型

[模型下载站pspice](https://www.pspice.com/models/analog-devices)

![image-20200429122511297](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429122511297.png)

下载所需得到的模型文件如下图，后缀为.cir

![image-20200429122605120](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429122605120.png)

### 步骤2 在Multisim中创建自定义元器件

此步骤可参考[NI Multisim元件库：在Multisim中创建自定义元器件](http://www.ni.com/tutorial/3173/zhs/)

1、打开软件点击**工具**》**元器件向导**

![image-20200429122751403](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429122751403.png)

![image-20200429122856893](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429122856893.png)

2、填入名称，选择需要的模型类型（仿真或封装footprint或者二者都要）下面的示例是二者都选的情形

这里建议查看需要创建的元器件的数据手册，选择合适的管脚数量和封装形式

![image-20200429123101557](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429123101557.png)

3、下一步编辑或导入仿真元件的原理图符号，如下图

![image-20200429123349713](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429123349713.png)

4、进入符号编辑窗口如图，需要设置好管脚名称和字体大小等参数

![image-20200429123451951](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429123451951.png)

![image-20200429123545099](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429123545099.png)

同样参照数据手册正确对应管脚名称，上图为成品图

完成设计的文件也可单独存储，便于下次调用，文件后缀为.sym

![image-20200429124359951](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124359951.png)

调用方法：选择已有的sym文件

![image-20200429124931786](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124931786.png)

5、下一步检查管脚和设置管脚参数，包括有分段元件的，需要注意

![image-20200429123648780](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429123648780.png)

6、对照数据手册，填写正确的管脚映射

![image-20200429123858753](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429123858753.png)

7、加载模型文件，选择我们之前下载的.cir文件

![image-20200429124033471](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124033471.png)

8、加载完后还要确认管脚映射

![image-20200429124155578](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124155578.png)

9、添加系列，存储至用户数据库

![image-20200429124254895](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124254895.png)

10、最后就可以像平时一样放置元件了

![image-20200429124322371](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124322371.png)

### 步骤3 在Multisim中导入和导出组件

1、进入**工具》数据库》数据库管理器**

![image-20200429124537783](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124537783.png)

2、选择所需的元件点导出或编辑即可

![image-20200429124646522](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124646522.png)

导出生成的文件格式为.prz

![image-20200429124716682](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429124716682.png)

---

### 问题1 Error The Model Contains Top-Level .subckt Statements in Multisim

问题描述

![image-20200429150002763](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429150002763.png)

>The model contains multiple top-level .subckt statements.
>
>Place any dependent .subckt or .model definitions within the main (top-level) .subckt

原因是我们下载的spice模型中含有多个主.subckt声明，其实这个问题和写c语言程序有两个主函数一样，自然会报错，但是最坑的是官网对这个错误的解释，竟然在讨论不恰当的缩进引起的问题，见参考资料[Error The Model Contains Top-Level .subckt Statements in Multisim](https://knowledge.ni.com/KnowledgeArticleDetails?id=kA00Z0000019VTuSAM&l=zh-CN)

---

解决方法：

使用Notepad++或Sublime Text类文本代码处理软件对.cir文件进行编辑

![image-20200429150629556](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429150629556.png)

![image-20200429150645384](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429150645384.png)

部分代码截图



可见官网下载的spice模型为了模型的通用性，写入了不同封装的管脚参数，所以如果我们直接把它导入肯定是会报错的。那么我们解决的方法就比较好办了，只保留我们需要的封装参数，把其余的代码删除即可。注意以.subckt开头，.ENDS结尾。

### 问题2 the prz file is from a different version,use the same version's application...

![image-20200429151452562](%E5%9C%A8Multisim%E4%B8%AD%E5%88%9B%E5%BB%BA%E8%87%AA%E5%AE%9A%E4%B9%89%E5%85%83%E5%99%A8%E4%BB%B6.assets/image-20200429151452562.png)

大意就是版本不兼容，笔者使用的是13.0的版本，在14.0的版本竟然打不开....

目前还真的没啥好办法，暂时只能将上述的.sym .cir文件发给别人让他自己照着这个步骤生成.prz文件 。

---

​                                                                          2020/4/29  Edited by David Du